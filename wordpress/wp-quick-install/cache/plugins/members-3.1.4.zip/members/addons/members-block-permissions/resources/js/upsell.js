/**
 * Upsell script.
 *
 * @package   MembersBlockPermissions
 * @author    Caseproof LLC
 * @copyright 2019 Caseproof LLC
 * @license   https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
 */

import MembersUpsell from './editor/filter-block-upsell';
